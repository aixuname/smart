

def greet():
    print('greeting from "module_in_sub_pack"')