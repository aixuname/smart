

print('Greeting from "example-package\__main__.py"')