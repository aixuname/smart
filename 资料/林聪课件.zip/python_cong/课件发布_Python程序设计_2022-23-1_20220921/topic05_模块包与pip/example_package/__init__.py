

print('greeting from example-package')

var_A_in_init = 10

var_A_in_init = 20

# class dog():