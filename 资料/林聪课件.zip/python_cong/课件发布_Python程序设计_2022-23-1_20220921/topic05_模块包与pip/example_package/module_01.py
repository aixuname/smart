

def greet():
    print('greeting from module_01.py in example-package')
	

print('These code are interpreted during "import". ')


