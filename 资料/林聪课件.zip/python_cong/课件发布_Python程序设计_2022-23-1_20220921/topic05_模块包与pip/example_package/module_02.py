

def main():
    pass


def greet():
    print('greeting from module_02.py in example-package')


if __name__ == '__main__':
    greet()
    print('called greet() from module_01.py')
	
	# 把代码段放这里 或者 写个具体的 main()






