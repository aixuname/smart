
# 2019 05 06

import sys

num_of_para = len(sys.argv)
for i in range(num_of_para):
    print('the argv[{0}] is : {1}'.format(i,sys.argv[i]))